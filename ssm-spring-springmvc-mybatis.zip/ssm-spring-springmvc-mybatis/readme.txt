ssm整合步骤：
ssm:spring+springmvc+mybatis
springmvc:视图层：用来接收用户请求，显示处理结果
spring：业务层，处理业务，管理dao，工具类对象
mybatis：持久层：访问数据库

用户发起请求-----》springmvc接收------》spring处理业务------》mybatis访问数据库
（然后向上一级返回，直至向用户展示处理结果）

ssm整合中有容器
1、第一个容器叫springmvc，管理controller控制器对象
2、第二个容器叫spring，管理service，dao，工具类对象
我们要做的就是把使用的对象交给合适的容器创建。把controller还有web开发相关的工具交给springmvc容器
把service，dao，工具类对象交给spring容器

springmvc和spring就像父子关系一样，springmvc看作继承了spring，子类可以访问父类中对象