package org.example.dao;

import org.example.domain.Student;

import java.util.List;

public interface StudentDao {
    //增
    int insertstudent(Student student);
    //查
    List<Student> selectstudent();
    //这里查询单个学生信息
    List<Student> selectstudent1(Integer id);
    //删
    int deletestudent(Integer id);
    //改
    int updatestudent(Integer id,String email);
}
