package org.example.service;

import org.example.domain.Student;

import java.util.List;

public interface StudentService {
    //注册学生
    int addstudent(Student student);
    //查询所有学生
    List<Student> findstudent();
    //删除学生
    int removestudent(Integer id);
    //更新学生
    int updatestudent(Integer id,String email);
    //查询单个学生
    List<Student> findstudent(Integer id);

}
