package org.example.service.impl;

import org.example.dao.StudentDao;
import org.example.domain.Student;
import org.example.service.StudentService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {
    @Resource
    //这个是引用类型自动注入,还有@Resource
    private StudentDao studentDao;
    @Override
    public int addstudent(Student student) {
        int nums = studentDao.insertstudent(student);
        return nums;
    }

    @Override
    public List<Student> findstudent() {
        return studentDao.selectstudent();
    }

    @Override
    public int removestudent(Integer id) {
        int nums = studentDao.deletestudent(id);
        return nums;
    }

    @Override
    public int updatestudent(Integer id,String email) {
        int nums = studentDao.updatestudent(id,email);
        return nums;
    }
    //查询单个学生信息
    @Override
    public List<Student> findstudent(Integer id) {
     return studentDao.selectstudent1(id);

    }
}
