package org.example.controller;

import org.example.domain.Student;
import org.example.service.StudentService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping("/Student")
public class StudentController {
    @Resource
    private StudentService service;

    //注册学生
    @RequestMapping("/addStudent.do")
    public ModelAndView addStudent(Student student){
        ModelAndView modelAndView = new ModelAndView();
        //调用service层
        String tips = "注册失败！";
        int nums = service.addstudent(student);
        if (nums > 0){
            //注册成功
            tips = student.getName() + "注册成功了，耶耶耶耶，您可真厉害，你是世界上最厉害的程序员！！！";
        }
        modelAndView.addObject("tips",tips);
        modelAndView.setViewName("result");
        return modelAndView;
    }

    //这里是查询所有学生
    @RequestMapping("/selectStudent.do")
    public  ModelAndView selectStudent(){
        List<Student> students = service.findstudent();
        ModelAndView modelAndView = new ModelAndView();
        for (Student stu:students) {
          System.out.println(students);
        }
        modelAndView.addObject("students",students);
        modelAndView.setViewName("result2");
        return modelAndView;
    }

    //删除学生
    @RequestMapping("/removeStudent.do")
    public ModelAndView removeStudent(Integer id){
        ModelAndView modelAndView = new ModelAndView();
        //调用service层
        String tips1 = "删除失败";
        int nums = service.removestudent(id);
        if (nums>0){
            tips1="删除成功";
        }
        modelAndView.addObject("tips1",tips1);
        modelAndView.setViewName("result3");
        return modelAndView;
    }
    //改动学生
    @RequestMapping("/updateStudent.do")
    public ModelAndView updateStudent(Integer id,String email){
        ModelAndView modelAndView = new ModelAndView();
        //调用service层
        String tips2 = "改动失败";
        int nums = service.updatestudent(id,email);
        if (nums>0){
            tips2="改动成功";
        }
        modelAndView.addObject("tips2",tips2);
        modelAndView.setViewName("result4");
        return modelAndView;
    }
    //查询单个学生信息
    @RequestMapping("/findStudent.do")
    public ModelAndView findStudent(Integer id){
        ModelAndView modelAndView = new ModelAndView();
        String tips3 = "学号不存在！";
        //调用service层
        List<Student> student= service.findstudent(id);
        if (id != null){
            for (Student stu:student) {
                System.out.println(student);
            }
        }else {

        }
        modelAndView.addObject("student",student);
        modelAndView.setViewName("result5");
        return modelAndView;
    }
}
